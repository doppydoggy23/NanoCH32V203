/*
 * kbcontrol.h
 *
 *  Created on: Feb 25, 2023
 *      Author: COS
 */

#ifndef USER_KBCONTROL_H_
#define USER_KBCONTROL_H_

void kbpresent(void);
void kbhandledata(uint8_t buffer[], int length);

#endif /* USER_KBCONTROL_H_ */
